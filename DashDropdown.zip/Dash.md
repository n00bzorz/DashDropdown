---
cssclass: homepage, dashboard, dropdowntable
share: true  
---
<center>
<span class="arrow" style="font-family:white rabbit; font-weight: normal; font-size: 29"> > :: DASHBOARD ::</span><span class="dash" style="font-size: 29"> _</span>
</center>


> [!multi-column]
> 
>> [!info|wide-3] + **Projects**
>> 
>> ![[Pasted image 20230713023442.png]]
![[dropdowns#^3i98sl]]
>
>> [!info|wide-3] + **Areas**
>> 
>> ![[Pasted image 20230713023442.png]]
![[dropdowns#^5x4i4b]]
> 
>> [!info|wide-3] + **Resources** 
>> 
>> ![[Pasted image 20230713023442.png]]
![[dropdowns#^o23ghr]]
>
>> [!info|wide-3] + **Archives** 
>> 
>> ![[Pasted image 20230713023442.png]]
![[dropdowns#^0u2a1t]]
>




